/**
 * Created by ali on 19/05/17.
 */
function scrollWin() {
    window.scrollBy({
        top: 1000, // could be negative value
        left: 0,
        // behavior: "smooth" have this for all scrolls in css
    });
}

AOS.init({
        duration: 1000,
    });